clear all;clc;close all;
% % 
load S_save_M_3_freqnum_20_nois_0
load Tt_generate_save_M_3_freqnum_20_nois_0

L=5;
CM=1;
 
np=[10 20 30 40 50 60 70 80 90;  %number of samples in individual sampleing
    90 80 70 60 50 40 30 20 10]; %number of samples in joint sampleing
coef=[];
for nnp1=1:9
    for ff=10:10:90
        coef=[coef;np(1,nnp1) np(2,nnp1) ff];  %ff size of joint frequency support
    end
end

 for aa=1:2
     aa_result{1,aa}=[];
 end
 lambda_vec=[1;1;0.01;0.1;1e-6];   %weights lambda
 
 for ii=1:length(coef(:,1))

    freqnum2=coef(ii,3);  %size of joint frequency support
    Np1=coef(ii,1);
    Np2=coef(ii,2);
      
    for cm=1:CM
        [ii,cm]
        S=S_save{cm,1};
       
        Tt_generate=Tt_generate_save{cm,1};
        [N,M]=size(Tt_generate);
        
        [Tf_est_temp,Tf_est_combin_temp]=joint_sampling_reconstruction_cvx_function(cm,freqnum2,L,Np1,Np2,M,lambda_vec,S,Tt_generate);  
  
       Tf_est{cm,1}=Tf_est_temp;
       Tf_est_combin(cm,:)=Tf_est_combin_temp';

    end
    
    Tf_est_combin(cm+1,:)=mean(Tf_est_combin,1);  %1-2   P_nrmse of reconstructed signals/ P_nrmse of selected samples db          
   
                                                                        % 
    iia=mod(ii-1,9)+1;
    aa_result{1,1}(:,iia)=Tf_est_combin(:,1); 
    aa_result{1,2}(:,iia)=Tf_est_combin(:,2); 
   

%     file_name=['result_M_' num2str(M) '_L_' num2str(L) '_freqnum_' num2str(freqnum2)  '_Np1_' num2str(Np1) '_Np2_' num2str(Np2) '_N_' num2str(N) '_CM_' num2str(CM2) '_alpha12_' num2str(lambda_vec(1,1)) '_alpha3_' num2str(lambda_vec(2*M+2,1)) '_alpha4_' num2str(lambda_vec(M+2,1)) '_alpha5_' num2str(lambda_vec(2*M+4,1)) '.mat'];
%     save(file_name);
    
    if mod(ii,9)==0
        file_name_aa_result=['aa_result_M_' num2str(M) '_L_' num2str(L) '_freqnum_' num2str(freqnum2) '_Np1_' num2str(Np1) '_Np2_' num2str(Np2) '_N_' num2str(N) '_CM_' num2str(CM)  '_alpha12_' num2str(lambda_vec(1,1)) '_alpha3_' num2str(lambda_vec(3,1)) '_alpha4_' num2str(lambda_vec(4,1)) '_alpha5_' num2str(lambda_vec(5,1)) '.mat'];
        save(file_name_aa_result,'aa_result');
%         figure;plot([1:CM]',Tf_est_combin(1:CM,1),'b-o'); xlabel('Number of samples in individual sampling');ylabel('P_{NRSME}');legend(['Np1=' num2str(Np1)]);title('Tf\_est\_combin');
        run calculate_result_db;
        for aa=1:2
            aa_result{1,aa}=[];
        end
    end
    
    clear Tf_est_combin; clear Tf_est;
    
 end

figure;plot(np(1,:)',Pnrmse_db(:,1),'r-s'); xlabel('Number of samples in individual sampling');ylabel('P_{NRSME} (dB)');legend(['reconstruction performance']); title('P_{NRMSE}');
