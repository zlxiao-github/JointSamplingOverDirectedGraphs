function [Tf_est,Tf_est_combin]=joint_sampling_reconstruction_cvx_function(cm,freqnum2,L,Np1,Np2,M,lambda_vec,S,Tt)


N = length(Tt(:,1));

[Q,T]=schur(S);

Tf=(Q')*Tt;
for ll_order=1:L
    if ll_order==1
        T_ll{ll_order,1}=eye(N);
        S_ll{ll_order,1}=eye(N);
    else
        T_ll{ll_order,1}=T_ll{ll_order-1,1}*T;
        S_ll{ll_order,1}=S_ll{ll_order-1,1}*S;
    end
end

for nn=1:N
    for ll_order=1:L
        phi{nn,1}(ll_order,:)=Q(nn,:)*T_ll{ll_order,1};
    end
end
% for nn=1:N    
%     for ll_order=1:L
%         phi{nn,1}(ll_order,:)=Q(nn,:)*T_ll{ll_order,1};
%         for mm=1:M
%             us_1{nn,mm}(ll_order,:)=Q(nn,:)*T_ll{ll_order,1}*Tf(:,mm);
%         end
%         us_1{nn,M+1}(ll_order,:)=Q(nn,:)*T_ll{ll_order,1}*sum(Tf,2);
%     end    
% end

for ll_order=1:L
    for mm=1:M
        uL{ll_order,mm}=S_ll{ll_order,1}*Tt(:,mm);
        for nn=1:N
            us_1{nn,mm}(ll_order,:)=uL{ll_order,mm}(nn,1);
        end
    end
    uL{ll_order,M+1}=S_ll{ll_order,1}*sum(Tt,2);
    for nn=1:N
        us_1{nn,M+1}(ll_order,:)=uL{ll_order,M+1}(nn,1);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% select vertices%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ver{1,1}=[1:N]';

u_samp_1=[];
Phi=[];
phi_leng=0;
SL_M_full=[];
rr_threshold=1e-7;

for nselect=1:Np1+Np2
%     [ii_ind,cm,nselect]
    flag_L(nselect,1)=1;
   for vn=1:length(ver{1,nselect})
       nn=ver{1,nselect}(vn,1);
       phi_temp=[Phi;phi{nn,1}];
      [~,rr{nn,nselect},~]=svd(phi_temp); 
      rr_diag{nn,nselect}=(diag(abs(rr{nn,nselect})));
      rr_diag_small(nn,nselect)=min(rr_diag{nn,nselect});
      rr_diag_length(nn,nselect)=length(find(rr_diag{nn,nselect}>rr_threshold))-phi_leng;
      
      rr_cond(nn,nselect)=cond(phi_temp);
   end
  
   rr_cond_temp=rr_cond(:,nselect);
   rr_cond_temp(rr_cond_temp==0)=inf;
   [rr_min_r1(nselect,1),ver_select_r1(nselect,1)]=min(rr_cond_temp);
   rr_min(nselect,1)=rr_min_r1(nselect,1);
   ver_select(nselect,1)=ver_select_r1(nselect,1);
   phi_select{ver_select(nselect,1),nselect}=phi{ver_select(nselect,1),1};
   
   %%%round 2
   vs=ver_select(nselect,1);
   [ver_maxlength(1,nselect),~]=max(rr_diag_length(:,nselect));
   if ver_maxlength(1,nselect)<1
       break;
   end
   
   if (ver_maxlength(1,nselect)>=1)&&(rr_diag_length(vs,nselect)~=L)
       ver_round2{1,nselect}=find(rr_diag_length(:,nselect)==ver_maxlength(1,nselect));
       for vn2=1:length(ver_round2{1,nselect})
           rr_cond_r2_temp=[];
            nn=ver_round2{1,nselect}(vn2,1);
            ver_3{nn,nselect}=nchoosek([1:L],ver_maxlength(1,nselect));
            for ii=1:length(ver_3{nn,nselect})
                phi_temp=[Phi;phi{nn,1}(ver_3{nn,nselect}(ii,:),:)];
                rr_cond_r2_temp(ii,1)=cond(phi_temp);
            end
            [rr_cond_r2(nn,nselect),ind_r2(nn,nselect)]=min(rr_cond_r2_temp);
            phi_select{nn,nselect}=phi{nn,1}(ver_3{nn,nselect}(ind_r2(nn,nselect),:),:);
            
       end

       rr_cond_temp_r2=rr_cond_r2(:,nselect);
       rr_cond_temp_r2(rr_cond_temp_r2==0)=inf;
       [rr_min_r2(nselect,1),ver_select_r2(nselect,1)]=min(rr_cond_temp_r2);
       rr_min(nselect,1)=rr_min_r2(nselect,1);
       ver_select(nselect,1)=ver_select_r2(nselect,1);
       
       flag_L(nselect,1)=0;
  end
   %%%
   
   ver_select_nodnum(nselect,1)=rr_diag_length(ver_select(nselect,1),nselect);
   Phi=[Phi;phi_select{ver_select(nselect,1),nselect}];

   if flag_L(nselect,1)==1   %flag_L=1 select all L shifted signals
        u_samp_1=[u_samp_1;us_1{ver_select(nselect,1),M+1}(1:ver_maxlength(1,nselect),:)];
   else
        u_samp_1=[u_samp_1;us_1{ver_select(nselect,1),M+1}((ver_3{ver_select(nselect,1),nselect}(ind_r2(ver_select(nselect,1),nselect),:))',:)];
   end
   phi_leng=length(Phi(:,1));
   ver{1,nselect+1}=setdiff(ver{1,nselect},ver_select(nselect,1));
   
   if rank(Phi)==N
       break;
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% calculate Joint frequency support%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cvx_begin
    cvx_solver SeDuMi;
    cvx_precision high;
    variable Tf_est_1(N)
    minimize( norm(Phi*Tf_est_1-u_samp_1,2) );
cvx_end
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


run("MultiSig_bestPhi_reconstruction_cvx");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 