err_temp=0;
for cm=1:CM
    err_temp(cm,1)=0;
    for fn=2:9
        err_temp(cm,fn)=aa_result{1,2}(cm,fn)-aa_result{1,2}(cm,fn-1);
    end
    [~,ind_temp(cm,1)]=min(err_temp(cm,:));

%     if err_temp(cm,ind_temp(cm,1))<-70
%         ind_temp(cm,1)=ind_temp(cm,1)-1;
%     end

    result_db(cm,1)=aa_result{1,1}(cm,ind_temp(cm,1));
end

result_db(CM+1,:)=mean(result_db,1);
Pnrmse_db(round(Np1/10),1)=result_db(CM+1,1);
%% figure;plot([1:CM]',result_db(1:CM,1),'r-s'); xlabel('Number of invidial samples');ylabel('P_{NRSME}');legend(['Np1=' num2str(Np1)]); title('result\_db');
% figure;plot(np(1,:)',aa_result{1,1}(CM+1,:),'b-o',np(1,:)',aa_result{1,2}(CM+1,:),'r--s'); 
% xlabel('Number of invidial samples');ylabel('P_{NRSME}(dB)');legend(['reconstruction performance of the whole signal'],['reconstruction performance of collected samples']); 