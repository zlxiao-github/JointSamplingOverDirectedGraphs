%v3 select samples more than K, use pinv


phi_NL=zeros(N,L);
for ii=1:length(ver_select)
   if flag_L(ii,1)==1
       phi_NL(ver_select(ii,1),:)=1;
   else
       phi_NL(ver_select(ii,1),ver_3{ver_select(ii,1),ii}(ind_r2(ver_select(ii,1),ii)',:))=1;
   end
end


[val_Tf_est_1_sort,ind_Tf_est_1_sort]=sort(abs(Tf_est_1),'descend');
freq_supp=ind_Tf_est_1_sort(1:freqnum2,1);

Tf_est_supp(:,1)=Tf_est_1;
Tf_est_supp(:,2)=Tf_est_1(ind_Tf_est_1_sort,1);
Tf_est_supp(:,3)=val_Tf_est_1_sort;
    energy_f=norm(val_Tf_est_1_sort);
    for nn=1:N
        Tf_est_supp(nn,4)=norm(val_Tf_est_1_sort(1:nn,1))/energy_f;
    end

freq_supp_sort=sort(freq_supp);
freq_supp_sort_diff=setdiff([1:N]',freq_supp_sort);

freq_sigma_indvidual=Tf_est_1(freq_supp_sort,:);
freq_sigma_joint=Tf_est_1(freq_supp_sort_diff,:);

us_samp_s{M+1,1}=[];%zeros(Np2,1);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Joint sampling and Invidial sampling%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Phi_NL_temp=phi_NL;
Phisamp_freqnum2=[];
Phisamp_full=[];
SL_M=[];
Phi_NL_individual=zeros(N,L);
for fn=1:Np1
    cond_Phisamp_temp=1e10*ones(N,L);

    for ll_order=1:L
        for nn=1:N
             if Phi_NL_temp(nn,ll_order)==1
                Phisamp_temp=[Phisamp_freqnum2;phi{nn,1}(ll_order,freq_supp_sort')];
                cond_Phisamp_temp(nn,ll_order)=cond(Phisamp_temp);                
             end
        end
    end
    [cond_row_phisamp(fn,:),ind_row_cond_phisamp(fn,:)]=min(cond_Phisamp_temp,[],1);
    [cond_min_phisamp(fn,1),ind_col_cond_phisamp(fn,1)]=min(cond_row_phisamp(fn,:));
    ind_row=ind_row_cond_phisamp(fn,ind_col_cond_phisamp(fn,1));
    ind_col=ind_col_cond_phisamp(fn,1);
    Phisamp_freqnum2=[Phisamp_freqnum2;phi{ind_row,1}(ind_col,freq_supp_sort')];
    Phisamp_full=[Phisamp_full;phi{ind_row,1}(ind_col,:)];
    cond_min_phisamp(fn,2)=ind_row;
    cond_min_phisamp(fn,3)=ind_col;
    for mm=1:M
        us_samp_s{mm,1}=[us_samp_s{mm,1};us_1{ind_row,mm}(ind_col,:)];
    end
    Phi_NL_temp(ind_row,ind_col)=0;
    Phi_NL_individual(ind_row,ind_col)=1;
end

Phisamp_top_full=Phisamp_full;
Phisamp_bottom_full=[];

for ll_order=1:L
    for nn=1:N
        if Phi_NL_temp(nn,ll_order)==1
            mm=M+1;
            us_samp_s{mm,1}=[us_samp_s{mm,1};us_1{nn,mm}(ll_order,:)];
            Phisamp_bottom_full=[Phisamp_bottom_full;phi{nn,1}(ll_order,:)];
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Phisamp{1,1}=Phisamp_top_full(:,freq_supp_sort);
Phisamp{1,2}=Phisamp_top_full(:,freq_supp_sort_diff);
Phisamp{1,3}=Phisamp_bottom_full(:,freq_supp_sort);
Phisamp{1,4}=Phisamp_bottom_full(:,freq_supp_sort_diff);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% reconstruct signal via cvx%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_col=N*M;
Phi_Con1=zeros(Np1*M,num_col);
Phi_Con2=zeros(Np2*1,num_col);
Phi_Con3=zeros(N,num_col);
Phi_Con4=zeros((N-freqnum2)*M,num_col);
us_samp_s_con1=zeros(Np1*M,1);
us_samp_s_con2=zeros(Np2*1,1);
us_samp_s_con3=zeros(N,1);
us_samp_s_con4=zeros((N-freqnum2)*M,1);

for mm=1:M
    Phi_Con1((mm-1)*Np1+1:mm*Np1,(mm-1)*N+1:mm*N)=[Phisamp{1,1},Phisamp{1,2}];
    Phi_Con2(1:Np2,(mm-1)*N+1:mm*N)=[Phisamp{1,3},Phisamp{1,4}];
    Phi_Con4((mm-1)*(N-freqnum2)+1:mm*(N-freqnum2),(mm-1)*N+freqnum2+1:(mm-1)*N+N)=eye(N-freqnum2);
    Phi_Con3(1:freqnum2,(mm-1)*N+1:(mm-1)*N+freqnum2)=eye(freqnum2);
    Phi_Con3(freqnum2+1:N,(mm-1)*N+freqnum2+1:(mm-1)*N+N)=eye(N-freqnum2);
    
    us_samp_s_con1((mm-1)*Np1+1:mm*Np1,:)=us_samp_s{mm,1};
    us_samp_s_con4((mm-1)*(N-freqnum2)+1:mm*(N-freqnum2),:)=zeros(N-freqnum2,1);
end
us_samp_s_con2(1:Np2,:)=us_samp_s{M+1,1};
us_samp_s_con3(1:freqnum2,:)=freq_sigma_indvidual;
us_samp_s_con3(freqnum2+1:N,:)=freq_sigma_joint;



cvx_begin
    cvx_solver SeDuMi;
    cvx_precision high;
    variable Tf_est_con(M*N)
    minimize( lambda_vec(1,1)*norm(Phi_Con1*Tf_est_con-us_samp_s_con1,2)+lambda_vec(2,1)*norm(Phi_Con2*Tf_est_con-us_samp_s_con2,2)+...
              lambda_vec(3,1)*norm(Phi_Con3*Tf_est_con-us_samp_s_con3,2)+lambda_vec(4,1)*norm(Phi_Con4*Tf_est_con-us_samp_s_con4,2)+...
              lambda_vec(5,1)*norm(Tf_est_con,2));
cvx_end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q_recon=[Q(:,freq_supp_sort),Q(:,freq_supp_sort_diff)];
for mm=1:M
   Tf_est(1:N,mm)=Tf_est_con((mm-1)*N+1:mm*N,1);
   Tt_est(1:N,mm)=Q_recon*Tf_est(1:N,mm);
   Tf_est(N+1,mm)=20*log10(norm(Tt_est(1:N,mm)-Tt(:,mm))/norm(Tt(:,mm)));   %reconstruction performance of the whole signal
   err_db(1,mm)=20*log10(norm(Tt_est(ver_select,mm)-Tt(ver_select,mm))/norm(Tt(ver_select,mm)));  %reconstruction performance of collected samples
end

Tf_est(N+1,M+1)=mean(Tf_est(N+1,1:M),2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Tf_est_combin=[Tf_est(N+1,M+1);mean(err_db)];

